export default function ProjectsPage() {
    return (
        <div className="flex items-center justify-center h-[50vh]">
            <p className="text-muted-foreground">Project management coming soon...</p>
        </div>
    )
}
